<template>
    <exception :type=404></exception>
</template>
<script>
import Exception from '@/components/Exception/index.vue';

export default {
  name: 'exception-404',
  components: {
    Exception,
  },
};
</script>
