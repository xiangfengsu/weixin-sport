<template>
    <exception :type=403></exception>
</template>
<script>
import Exception from '@/components/Exception/index.vue';

export default {
  name: 'exception-403',
  components: {
    Exception,
  },
};
</script>
