<template>
    <exception :type='500'></exception>
</template>
<script>
import Exception from '@/components/Exception/index.vue';

export default {
  name: 'exception-500',
  components: {
    Exception,
  },
};
</script>
