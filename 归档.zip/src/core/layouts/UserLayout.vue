<template>
<div class="userlayout">
  <router-view></router-view>
</div>
</template>
<script>
export default {
  name: 'user-layout',
};
</script>
<style lang="scss">

</style>
